package com.ovs.dugu.acc.dev.form;

public class VoterForm {
	private String name;
	private String state;
	private String dist;
	private int age;
	private String gender;
	private String voterType;
	private String candidatesSign;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDist() {
		return dist;
	}

	public void setDist(String dist) {
		this.dist = dist;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getVoterType() {
		return voterType;
	}

	public void setVoterType(String voterType) {
		this.voterType = voterType;
	}

	public String getCandidatesSign() {
		return candidatesSign;
	}

	public void setCandidatesSign(String candidatesSign) {
		this.candidatesSign = candidatesSign;
	}

}

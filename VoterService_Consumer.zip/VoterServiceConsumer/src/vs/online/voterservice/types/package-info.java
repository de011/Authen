@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.online.vs/VoterService/types")
package vs.online.voterservice.types;

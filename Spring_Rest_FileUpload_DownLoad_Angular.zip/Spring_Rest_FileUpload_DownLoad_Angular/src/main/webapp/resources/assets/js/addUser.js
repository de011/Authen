var app = angular.module("fileuploadmodule", []);
app.controller("myctrl", ["$scope", "$http", "$log","$timeout",
                          function(scope, http, customerservice, log, $timeout) {

	scope.show=function(){
		alert("Show clicked");
	}
	
}]);

var app = angular.module("fileuploadmodule", []);
app.controller("myctrl", ["$scope", "$http", "$log","$timeout",
                          function(scope, http,log, $timeout) {

	scope.base64image;
	scope.searchshow=false;
	scope.formshow=false;
	scope.loadingshow=false;
	scope.searchattribute;
	scope.show=function(base64image){
		scope.base64image=base64image;
	}
	
	scope.showAddUser=function(){
		scope.searchshow=false;
		scope.formshow=true;
		scope.fname="";
        scope.lname="";
       $('#preview').removeAttr('src');
	}
	scope.showSearch=function(){
		scope.searchshow=true;
		scope.formshow=false;
	}
	
	scope.submit = function() {
        scope.loadingshow = true;
        scope.searchshow = false;
    	scope.formshow=false;
        alert(scope.selectedlang);
        var data = {
            
            "fname": scope.fname,
            "lname": scope.lname,
            "pic": scope.base64image,
        }

        http.post("add.do", data, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(function(success) {
            
            	$timeout(function() {
            		    scope.loadingshow = false;
                }, 4000);
            	scope.searchattribute="";
                console.log(success);

            }, function(error) {
                alert("inside error");
            }
            );
    }

	
	
	 scope.searchuser = function() {
         scope.loadingshow = true;
         scope.searchshow = false;
         http.get('search.do', {
             params: {
                 email: scope.searchattribute
             }
         }).then(function(success) {
             scope.show = true;
             console.log(success.data);
             scope.fname = success.data.fname;
             //scope.lname = success.data.lName;
         	 scope.loadingshow = false;
             var imagedata="data:image/jpeg;base64,"+success.data.pic;
             $('#preview').removeAttr('src');
             $('#preview').attr('src',imagedata);
             scope.formshow=true;

         }, function(error) {
             scope.show = false;
             scope.showsuccessmessage = true;
             console.log(error);
             scope.successmessage = error.data.message;
             $timeout(function() {
                 scope.showsuccessmessage = false;
             }, 9000);
             console.log(error);
         });
     }

	
	
}]);


app.directive('myDirective', function () {
    return {
        restrict: 'A',
        scope: true,
        link: function (scope, element, attr) {

        	
            element.bind('change', function () {
            	/*console.log(element[0].files[0]);
                var formData = new FormData();
                formData.append('file', element[0].files[0]);
                alert("Change");*/
            	scope.base64image;
                var file = element[0].files[0];
                var reader = new FileReader();
                reader.onloadend = function() {
               
                 $('#preview').attr('src',reader.result);
                	scope.base64image=reader.result.replace("data:image/jpeg;base64,","");
                	 scope.show(scope.base64image);
                }
                reader.readAsDataURL(file)
            });
            
        }
    };
});

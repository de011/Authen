package org.fileoperation.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.imageio.ImageIO;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class FileController {
	public List<String>  users;
	FileController(){
		users=new ArrayList<>();
	}
	@RequestMapping(value="/add",method=RequestMethod.POST,produces=MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String uploadUseraData(@RequestBody UserBo userbo){
		users.add(userbo.getFname());
		BufferedImage image = null;
		byte[] imageByte;

		 imageByte = Base64.getDecoder().decode(userbo.getPic());
		ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
		try {
			image = ImageIO.read(bis);
			bis.close();
			// write the image to a file
			File outputfile = new File("D:/Photos/"+userbo.getFname()+".jpeg");
			ImageIO.write(image, "jpeg", outputfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "hii";
	}

	@RequestMapping(value="/search",method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<UserBo> getUser(@RequestParam(value="email") String email) throws IOException{
		UserBo bo= new UserBo();
		if(users.contains(email)){
			byte[] array = Files.readAllBytes(new File("D:\\Photos\\"+email+".jpeg").toPath());
			String base64String = Base64.getEncoder().encodeToString(array);
			bo.setFname(email);
			bo.setLname("Some Dummy Name");
			bo.setPic(base64String);
		    
		}
		return new ResponseEntity<UserBo>(bo, HttpStatus. ACCEPTED);
		
	}
}

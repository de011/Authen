package com.controller.test.testcontrollerexample;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.controller.beans.User;
import com.controller.service.HelloService;

@RestController
@RequestMapping("/hello")
public class HelloResource {
	private HelloService helloService;
	
	public HelloResource(HelloService helloService) {
		this.helloService = helloService;
	}

	@GetMapping
	public String helloWorld(){
		return helloService.hello();
		
	}
	
	@GetMapping(value="/json" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public User getUserDetails(){
		
		return new User("dileep", "vizag");
	}
	@PostMapping(value="/post",consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public User CreateRegistraction(@RequestBody User user){
		return user;
		
	}

}

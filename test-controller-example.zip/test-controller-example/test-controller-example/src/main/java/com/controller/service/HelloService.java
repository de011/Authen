package com.controller.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {

	public String hello() {
		// TODO Auto-generated method stub
		return "hello world";
	}

}

# Spring-security-LDAP
How to use LDAP for Authentication using spring 

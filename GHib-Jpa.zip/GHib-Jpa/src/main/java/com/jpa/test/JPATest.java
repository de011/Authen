package com.jpa.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jpa.entities.Address;

public class JPATest {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction transaction = null;
		boolean flag = false;
		entityManagerFactory = Persistence.createEntityManagerFactory("automobile");
		entityManager = entityManagerFactory.createEntityManager();
		transaction = entityManager.getTransaction();
		transaction.begin();
		try {
			Address address = new Address();
			address.setAddressId(1040);
			address.setAddressLine1("405");
			address.setAddressLine2("Hi-tech");
			address.setCity("HYD");
			address.setState("TS");
			address.setZip(5000150);
			address.setCountry("india");

			entityManager.persist(address);
			flag = true;
			System.out.println("Data is stored sucessfully");
		} finally {
			if (entityManager != null && transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				entityManager.close();
			}
			entityManagerFactory.close();
		}
	}
}
